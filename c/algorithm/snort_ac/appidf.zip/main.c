#include <stdio.h>
#include <stdlib.h>
#include "appidf.h"

typedef struct t_node
{
	struct t_node  *next;
	int    lenth;
	unsigned char*  data;
}node;

typedef struct t_pcapData
{
	node  *head;
	int   count;
}pcapData;

typedef struct t_IPv4header
{
	uint8_t ver_hdl;
	uint8_t tos;
	uint16_t len;
	uint16_t id;
	uint16_t flag;
	uint8_t ttl;
	uint8_t proto;
	uint16_t checksum;
	uint32_t s_addr;
	uint32_t d_addr;
}IPV4header;

typedef struct t_TCPheader
{
	uint16_t s_port;
	uint16_t d_port;
	uint32_t sn;
	uint32_t ack;
	uint8_t hd_len;
	uint8_t flag;
	uint16_t other[3];
}TCPheader;

#define URL_LENGTH 128

struct url_buff
{
    int len;
    uint8_t content[URL_LENGTH + 1];
};




typedef struct t_flow_info
{
    uint32_t f_apptype; 
	uint32_t f_pos_type;
	uint16_t p_apptype;
    uint16_t FTP_port ;
    uint16_t ftp_data;
    struct temp_port_ip *pip;   
    int f_pair;
    uint8_t is_port; 
	uint8_t is_rtspxml; 
	uint8_t is_payload;
	uint8_t is_http; 
	uint8_t f_urlflag;
	struct url_buff *f_urlbuff;
	char buffer[128];
	char identify_status[20];
	char identify_pos_status[20];
	uint8_t c2s_dir;
	uint8_t flowstat;
}T_flow_info;


int http_url_inspect(struct pcapData *pkt);



T_flow_info   flow_info;
int main(int argc, char* argv[])
{
	printf("init begin!-------");
    FILE *pSrcFile;
    unsigned int size ;
	pcapData     pcap_data;
	node        *pnow, *ptmp;
    unsigned int i = 24;
    unsigned int dwLenth;
    pSrcFile = fopen(argv[1],"rb");
    fseek(pSrcFile,0,SEEK_END);
    size = ftell(pSrcFile);
    rewind(pSrcFile);
    fseek(pSrcFile,24,1);
	
	pnow = (node*)malloc(sizeof(node));
	fseek(pSrcFile, 8, 1);
    dwLenth = 0;
    fread(&dwLenth,4,1,pSrcFile);
	pnow->data = (unsigned char*)malloc(dwLenth);
    fseek(pSrcFile, 4, 1);
    fread(pnow->data,8,dwLenth/8,pSrcFile);
    fread(pnow->data,1,dwLenth%8,pSrcFile);
    i += (dwLenth + 16);
	pcap_data.head = pnow;
	pcap_data.count = 1;
	
    while(i < size)
	{
		ptmp = (node*)malloc(sizeof(node));
		fseek(pSrcFile, 8, 1);
	    dwLenth = 0;
	    fread(&dwLenth,4,1,pSrcFile);
		ptmp->data = (unsigned char*)malloc(dwLenth);
	    fseek(pSrcFile, 4, 1);
	    fread(ptmp->data,8,dwLenth/8,pSrcFile);
	    fread(ptmp->data,1,dwLenth%8,pSrcFile);
	    i += (dwLenth + 16);
		pnow->next = ptmp;
		pcap_data.count ++;		
		pnow = ptmp;	    
    }
	pnow->next = NULL;
	
	printf("------------");
	printf("pktcount = %d",pcap_data.count);

	pthread_t tid;
	int res, err;
	pthread_rwlock_init(&identifier_lock, NULL);
    init_temp_port_ip();
	idf_tree = malloc(sizeof(*idf_tree));	
	res = init_identifier_map(&idf_tree ,"protocol_list.lst");
	if(res != 1) 
	{
		printf("Create AppTree failed!\n");
	}
	pthread_attr_t thrattr;
	pthread_attr_init(&thrattr);
	err = pthread_create(&tid, &thrattr, do_temp_port_ip_scan, NULL);
    if (err) 
	{
        printf("do_temp_port_ip_scan pthread create failed\n");
    }	
    printf("\n-------- complete\n");

	unsigned char  *pData;
	IPV4header  *pipheader;
	TCPheader   *pTCPheader;
	int ip_len;
	struct Pkt_info * pkt_info;
	int icount;
	int httpflag = 0;
	for(icount = 0; icount < pcap_data.count; icount++)
	{
		pData = pcap_data.head->data;
		pData += 14;  //eth header lenth
		
		pipheader = (IPV4header*)pData;		
		pkt_info = (struct Pkt_info *)malloc(sizeof(struct Pkt_info));
		memset(pkt_info, 0, sizeof(*pkt_info));		
		pkt_info->sip.type = IPV4;
		pkt_info->dip.type = IPV4;
		pkt_info->sip.ip4_addr = *(struct in_addr*)(&pipheader->s_addr);
		pkt_info->dip.ip4_addr = *(struct in_addr*)(&pipheader->d_addr);	
		pkt_info->l4type = pipheader->proto;
		ip_len = pipheader->len;		
		pData += 20;  //ip header lenth;

		pTCPheader = (TCPheader*)pData;
		pkt_info->sport = pTCPheader->s_port;
		pkt_info->dport = pTCPheader->d_port;

		if (flow_info.is_http == 1 || pkt_info->dport == ntohs(80) || pkt_info->sport == ntohs(80) ||
			pkt_info->dport == ntohs(8080) || pkt_info->sport == ntohs(8080) ) 
		{ 
			pkt_info->p_apptype = 10;  //http
			httpflag = 1;
		}	
		
		
		
		
		//int httpflag = http_url_inspect(packet);

		
		pkt_info->l4hdrlen = (pTCPheader->hd_len >> 4) << 2;
		pkt_info->l5len = ip_len - 20 - pkt_info->l4hdrlen; 
		//pkt_info->url_len = packet->p_flow->fa_what->f_urlbuff->len;

		pkt_info->l4 = pData;	
		pkt_info->l5 = pData + pkt_info->l4hdrlen; 

		pkt_info->buffer = flow_info.buffer;	   
		pkt_info->identify_status = flow_info.identify_status;
//		pkt_info->url_content = packet->p_flow->fa_what->f_urlbuff->content;
	
//		pkt_info->p_thread = packet->p_thread;
	
	
		pkt_info->f_apptype = flow_info.f_apptype;
		pkt_info->f_pos_type = flow_info.f_pos_type; 
		pkt_info->p_apptype = flow_info.p_apptype;
		pkt_info->is_port = flow_info.is_port;
		pkt_info->is_rtspxml = flow_info.is_rtspxml;
		pkt_info->is_payload = flow_info.is_payload;
		pkt_info->fpip = flow_info.pip; 	
		pkt_info->identify_pos_status = flow_info.identify_pos_status;
	
		appidf(pkt_info, icount, httpflag);
		printf("the f_apptype is %d , p_apptype is %d  ,f_pos_type is %d\n",pkt_info->f_apptype,pkt_info->p_apptype,pkt_info->f_pos_type);

	
		flow_info.f_apptype = pkt_info->f_apptype;
		flow_info.f_pos_type = pkt_info->f_pos_type;	
		flow_info.p_apptype = pkt_info->p_apptype; 	
		flow_info.is_port = pkt_info->is_port;
		flow_info.is_rtspxml = pkt_info->is_rtspxml;
		flow_info.is_payload = pkt_info->is_payload;
		flow_info.pip = pkt_info->fpip;	
		free(pkt_info);

		}

		

       //*/
		
	pcap_data.head = pcap_data.head->next;	
    fclose(pSrcFile);
 
}

