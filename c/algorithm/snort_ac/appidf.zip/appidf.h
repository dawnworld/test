#ifndef _APPIDF_H_
#define _APPIDF_H_

#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <pthread.h>
#define MAX_PROTOCOL_NUMBER 6400   
#define MAX_FILE_NAME   256
#define MAX_STATU_NAME 20
#define MAX_APP_NAME 20
#define MAX_APP_NUM MAX_PROTOCOL_NUMBER
#define MAX_TYPE_NUM 30  

#define CAPTHREADS 4
#define URL_LENGTH 128  
#define STRING_LENGTH 256  

#define IPV4 0
#define IPV6 1

struct ip_address {  
    union {
        struct in_addr ip4;
        struct in6_addr ip6;
    } addr;
#define ip4_addr addr.ip4
#define ip6_addr addr.ip6
    uint8_t type;
};
struct Pkt_info
{
    char *identify_status;  
    char *identify_pos_status; 
    uint8_t *pos_status;
    uint8_t l4type;    
    struct temp_port_ip * fpip; 
    uint32_t f_apptype;
    uint16_t p_apptype;
    uint32_t f_pos_type;
    uint8_t is_port;
    uint8_t is_payload;  
    uint8_t pktcount; 
    uint8_t is_rtspxml; 
    uint8_t *l4;
    uint8_t *l5;    int l5len;
    int l4hdrlen;
    char p_thread;
    uint16_t sport;
    uint16_t dport; 
    struct ip_address sip;
    struct ip_address dip;    
    unsigned char *buffer;  
    int url_len;       
    uint8_t *url_content;

    uint8_t acmatch[MAX_APP_NUM][MAX_TYPE_NUM];  
};

typedef enum {
    NO_ACT,
    PORT,           
    IP,
    LENGTH,
    URL,
    CHAR,
    STRING,
    CONTENT_LENTH,
    HTTP_CONTENT_LENTH,      
    CONTENT_CONTENT,
    BUFFER_ADD,
    BUFFER_JUDGE,
    BUFFER_SAVE,
    ADDPORT,
    ADDOUTPORT 
} identifier_cluster_type;

typedef struct {
    identifier_cluster_type cluster_type;
    int offset;
    uint8_t content;
    uint8_t is_http;     
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_char;

typedef struct {
    identifier_cluster_type cluster_type;
    int offset;
    char content[STRING_LENGTH];  
    uint16_t string_length;
    int not_flag;
    uint8_t is_http;    
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_string;

typedef struct {
    identifier_cluster_type cluster_type;
    uint16_t offset;
    uint8_t byte_number;
    uint8_t differ_value;
    uint8_t is_http;    
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_content_length;

typedef struct
{
    identifier_cluster_type cluster_type;
    uint16_t offset;
    int min_http_length;
    int max_http_length;
    uint8_t byte_number;
    uint8_t differ_value;
    uint8_t is_http;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_http_content_length;        

typedef struct {
    identifier_cluster_type cluster_type;
    uint16_t offset0;
    uint16_t offset1;
    uint16_t length;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_content_content;

typedef struct {
    identifier_cluster_type cluster_type;
    uint16_t buffer_offset;
    uint8_t addvalue;

    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_buffer_add;

typedef struct {
    identifier_cluster_type cluster_type;
    unsigned int buffer_offset;
    unsigned int payload_offset;
    unsigned int width;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_buffer_judge;

typedef struct {
    identifier_cluster_type cluster_type;
    uint16_t buffer_offset;
    uint16_t payload_offset;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_buffer_save;

typedef struct {
    identifier_cluster_type cluster_type;
    char url_content[URL_LENGTH + 1];
    int url_len;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_url;

typedef struct {
    identifier_cluster_type cluster_type;
    uint8_t is_ftp;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_addport;

typedef struct {
    identifier_cluster_type cluster_type;
    int port_start;
    int port_end;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_port;

typedef struct {
    identifier_cluster_type cluster_type;
    uint32_t length_start;
    uint32_t length_end;
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_length;

#define IP_RANGE_IN   1
#define IP_RANGE_OUT  2
#define IP_RANGE_BOTH 3
#define IP_MASK_IN   4
#define IP_MASK_OUT  5
#define IP_MASK_BOTH 6

typedef struct {
    identifier_cluster_type cluster_type;
    uint8_t ip_type;
    union {
        struct ip_range {
            struct in_addr ip_start;
            struct in_addr ip_end;
        } range;
        struct ip_mask {
            struct in_addr ip;
            struct in_addr netmask;
        } mask;
    } content;
#define cl_ipstart content.range.ip_start
#define cl_ipend content.range.ip_end
#define cl_ipself content.mask.ip
#define cl_ipmask content.mask.netmask
    void *next_cluster;
    identifier_cluster_type next_cluster_type;
} identifier_cluster_ip;

typedef struct _identifier_header {
    uint32_t type;
    uint8_t is_pos;
    uint8_t isTCP_UDP;
    uint8_t isstatu;
    int payloadlength;
    uint8_t isfinalstatu;
    char statu[MAX_STATU_NAME];
    char pre_statu[MAX_STATU_NAME];
    uint8_t isstring; 
    uint8_t value;
    uint8_t priority;
    uint16_t min_plen;
    uint16_t max_plen;
    void *first_cluster;
    identifier_cluster_type first_cluster_type;
    struct _identifier_header *next_header;
} identifier_header;

typedef struct {
    char file_name_list[MAX_PROTOCOL_NUMBER][MAX_FILE_NAME];
    int protocol_number;
} protocol_identifier_list;

typedef struct {
    char app_name_list[MAX_APP_NUM][MAX_APP_NAME];
    int app_number;
} App_Name_List;

typedef struct _identifier_tree_node {
    uint16_t plen;
    struct _identifier_tree_node *left_small;
    struct _identifier_tree_node *right_big;
    struct _identifier_header *left_first_header, *right_first_header;
} identifier_tree_node;

struct temp_port_ip {
    struct ip_address ip;  
    uint32_t app_type;
    uint64_t pkts[CAPTHREADS];
    struct temp_port_ip *next;
};

struct AC_String {  
    uint32_t type;
    int id;
    uint8_t isTCP_UDP;
    char content[STRING_LENGTH];  
    uint16_t string_length;
    int offset; 
    int not_flag;
    uint8_t is_http; 
    uint8_t is_url;   
    int pid;    
};  
struct AC_String *tcp_ac_string_list[MAX_APP_NUM][MAX_TYPE_NUM]; 
struct AC_String *udp_ac_string_list[MAX_APP_NUM][MAX_TYPE_NUM]; 


typedef struct {
    struct temp_port_ip *temp_port_ip_list[65536];  
    struct temp_port_ip *temp_port_ip_repos;
    int temp_port_ip_cnt;
    pthread_rwlock_t temp_port_ip_list_lock;
} Temp_repos;

typedef struct {
    uint32_t tcp_port_app_list[65536];  
    uint32_t tcp_port_pos_list[65536];  
    uint32_t udp_port_app_list[65536];
    uint32_t udp_port_pos_list[65536];
} Port_list;

#define TEMP_PORT_IP_THRESHOLDS 0
#define TEMP_PORT_IP_MAX 10000
typedef struct {
    identifier_tree_node *tcp_identifier_root;
    identifier_tree_node *udp_identifier_root;
    Port_list port_list;
} Identifier_tree;

extern Identifier_tree * idf_tree; 
extern pthread_rwlock_t identifier_lock;
extern Temp_repos * temp_repos;

void init_temp_port_ip(void);  

void *do_temp_port_ip_scan(void *_arg);/*main.c�ж����߳�*/

int init_identifier_map(Identifier_tree ** temp_idf_tree, char *list); 
void free_identifier_map(Identifier_tree * idf_tree);            
 
void appidf(struct Pkt_info * pkt_info, long pktcount, int httpflag); 

#endif


